import svgPaths from "./svg-ao060ufb81";
import imgFrame12 from "./00f4884bd9c2d626ba21411a644c48069501bc75.png";
import imgHandAndIPhone16Pro from "./74578aaa1c3f1c63e981fbfd98a187b32d3c58f2.png";
import imgIPhone16Pro from "./72b491ff66c3ba28a9bba13495704e3164a0360c.png";
import imgImage1 from "./7d358d9bdfa41a9c0755e094e84d060c05d955a4.png";
import imgFrame19 from "./68c3f76b17e79a96fbcaeb2b520abe4babbea7f0.png";
import imgFrame20 from "./5b2e10c74bab3b1c82e5c5810e51e6b64a41d729.png";
import imgImage2 from "./af2ce6c18fb80ff38a1662062ceeaf20a5e1b098.png";
import imgHpEliteDragonfly from "./448979ebe7a09d11c3ce7ca24e6daa448bf4c059.png";
import imgMacBookAir15Inch from "./572f587fd3a9cf47d78cef64d1e5a896bd72ce42.png";
import imgIPhone13 from "./c72db78ab807f0396cb8d8e3cc98beb7c07a9291.png";
import imgFrame25 from "./9ca749a4062a327037762d25b236f5ddb0451206.png";
import imgFrame26 from "./ece298d0ec2c16f10310d45724b276a6035cb503.png";
import imgIPhone14 from "./7c3b0816e918b94b54b60a0548ad54fc785c2375.png";
import imgHandAndIPhone16Pro1 from "./5982b246dd1acf2cf41bb2a7eda2676eb4389e61.png";

function Frame10() {
  return (
    <div className="relative rounded-[100px] shrink-0 size-[55px]">
      <div className="absolute inset-0 overflow-hidden pointer-events-none rounded-[100px]">
        <img alt="" className="absolute h-[133.22%] left-0 max-w-none top-[-16.61%] w-full" src={imgFrame12} />
      </div>
    </div>
  );
}

function Frame11() {
  return (
    <div className="content-stretch flex flex-col font-['Aeonik_TRIAL:Regular','Noto_Sans:Regular',sans-serif] h-[54px] items-start justify-between leading-[normal] relative shrink-0 text-[20px] w-[129px] whitespace-nowrap">
      <p className="relative shrink-0 text-black" style={{ fontVariationSettings: "'CTGR' 0, 'wdth' 100, 'wght' 400" }}>
        Diego Méndez
      </p>
      <p className="relative shrink-0 text-[#525252]" style={{ fontVariationSettings: "'CTGR' 0, 'wdth' 100, 'wght' 400" }}>
        Lima, Perú
      </p>
    </div>
  );
}

function Frame6() {
  return (
    <div className="content-stretch flex gap-[10px] h-[69px] items-center relative shrink-0 w-[254px]">
      <Frame10 />
      <Frame11 />
    </div>
  );
}

function Frame5() {
  return (
    <div className="content-stretch flex h-[70px] items-center justify-center relative shrink-0 w-[254px]">
      <Frame6 />
    </div>
  );
}

function Frame2() {
  const scrollToSection = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  return (
    <div className="content-stretch flex h-[29px] items-center justify-between leading-[normal] relative shrink-0 text-[20px] text-black w-[485px] whitespace-nowrap">
      <button onClick={() => scrollToSection('about')} className="font-['Aeonik_TRIAL:Regular','Noto_Sans:Regular',sans-serif] relative shrink-0 cursor-pointer hover:opacity-70 transition-opacity" style={{ fontVariationSettings: "'CTGR' 0, 'wdth' 100, 'wght' 400" }}>
        Acerca de Mí
      </button>
      <button onClick={() => scrollToSection('projects')} className="font-['Aeonik_TRIAL:Regular',sans-serif] not-italic relative shrink-0 cursor-pointer hover:opacity-70 transition-opacity">Proyectos</button>
      <a href="https://medium.com/@diegomdz" target="_blank" rel="noopener noreferrer" className="font-['Aeonik_TRIAL:Regular',sans-serif] not-italic relative shrink-0 cursor-pointer hover:opacity-70 transition-opacity">Blog</a>
      <button onClick={() => scrollToSection('experience')} className="font-['Aeonik_TRIAL:Regular',sans-serif] not-italic relative shrink-0 cursor-pointer hover:opacity-70 transition-opacity">Curriculum</button>
    </div>
  );
}

function Frame4() {
  return (
    <div className="content-stretch flex flex-col h-[69px] items-center justify-center relative shrink-0 w-[539px]">
      <Frame2 />
    </div>
  );
}

function Call() {
  return (
    <div className="relative shrink-0 size-[25px]" data-name="call">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 25 25">
        <g id="call">
          <path d={svgPaths.p24398c00} fill="var(--fill-0, white)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Frame8() {
  return (
    <div className="content-stretch flex h-[29px] items-center relative shrink-0">
      <p className="font-['Aeonik_TRIAL:Bold','Noto_Sans:Bold',sans-serif] leading-[normal] relative shrink-0 text-[20px] text-white whitespace-nowrap" style={{ fontVariationSettings: "'CTGR' 0, 'wdth' 100, 'wght' 700" }}>
        Contáctame
      </p>
    </div>
  );
}

function Frame7() {
  const handleContact = () => {
    document.getElementById('footer')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  return (
    <button onClick={handleContact} className="bg-black content-stretch flex gap-[10px] h-[60px] items-center justify-center relative rounded-[35px] shrink-0 w-[201px] cursor-pointer hover:opacity-80 transition-opacity">
      <Call />
      <Frame8 />
    </button>
  );
}

function Frame() {
  return (
    <div className="content-stretch flex h-[61px] items-center justify-between relative shrink-0 w-[1454px]">
      <Frame5 />
      <Frame4 />
      <Frame7 />
    </div>
  );
}

function Frame12() {
  return (
    <div className="content-stretch flex flex-col gap-[15px] h-[212px] items-center justify-center relative shrink-0 text-black text-center">
      <p className="font-['Aeonik_TRIAL:Regular','Noto_Sans:Regular',sans-serif] leading-[normal] relative shrink-0 text-[20px] w-[850px]" style={{ fontVariationSettings: "'CTGR' 0, 'wdth' 100, 'wght' 400" }}>
        Diseñador UX/UI Disponible
      </p>
      <p className="font-['Aeonik_TRIAL:Regular',sans-serif] leading-[0] not-italic relative shrink-0 text-[0px] w-[1154px]">
        <span className="leading-[normal] text-[68px]">{`Experiencias digitales que todos puedan `}</span>
        <span className="font-['Aeonik_TRIAL:Bold',sans-serif] leading-[normal] text-[68px]">usar</span>
        <span className="leading-[normal] text-[68px]">{` y `}</span>
        <span className="font-['Aeonik_TRIAL:Bold',sans-serif] leading-[normal] text-[68px]">disfrutar</span>
      </p>
    </div>
  );
}

function Call1() {
  return (
    <div className="relative shrink-0 size-[25px]" data-name="call">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 25 25">
        <g id="call">
          <path d={svgPaths.p24398c00} fill="var(--fill-0, white)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Frame16() {
  return (
    <div className="content-stretch flex h-[29px] items-center relative shrink-0">
      <p className="font-['Aeonik_TRIAL:Bold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[20px] text-white whitespace-nowrap">Agenda un Meet</p>
    </div>
  );
}

function Frame15() {
  const handleMeet = () => {
    window.open('https://calendly.com/tu-usuario', '_blank');
  };

  return (
    <button onClick={handleMeet} className="bg-black content-stretch flex gap-[10px] h-[54px] items-center justify-center relative rounded-[35px] shrink-0 w-[262px] cursor-pointer hover:opacity-80 transition-opacity">
      <Call1 />
      <Frame16 />
    </button>
  );
}

function Chatbubble() {
  return (
    <div className="relative shrink-0 size-[25px]" data-name="chatbubble">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 25 25">
        <g id="chatbubble">
          <path d={svgPaths.pefccb80} fill="var(--fill-0, black)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Frame18() {
  return (
    <div className="content-stretch flex h-[29px] items-center relative shrink-0">
      <p className="font-['Aeonik_TRIAL:Bold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[20px] text-black whitespace-nowrap">Enviame un mensaje</p>
    </div>
  );
}

function Frame17() {
  const handleMessage = () => {
    window.open('https://wa.me/51973853069?text=Hola%20Diego,%20me%20gustaría%20contactarte', '_blank');
  };

  return (
    <button onClick={handleMessage} className="content-stretch flex gap-[10px] h-[54px] items-center justify-center relative rounded-[35px] shrink-0 w-[261px] cursor-pointer hover:opacity-80 transition-opacity">
      <div aria-hidden="true" className="absolute border border-[#8d8d8d] border-solid inset-[-1px] pointer-events-none rounded-[36px]" />
      <Chatbubble />
      <Frame18 />
    </button>
  );
}

function Frame13() {
  return (
    <div className="content-stretch flex gap-[10px] h-[56px] items-center justify-center relative shrink-0 w-[1154px]">
      <Frame15 />
      <Frame17 />
    </div>
  );
}

function Frame14() {
  return (
    <div className="content-stretch flex flex-col gap-[25px] h-[421px] items-center justify-center relative shrink-0 w-full">
      <Frame12 />
      <Frame13 />
    </div>
  );
}

function Frame20() {
  return (
    <div className="bg-black content-stretch flex gap-[10px] h-[353px] items-center justify-center overflow-clip relative rounded-[25px] shrink-0 w-[442px]">
      <div className="absolute h-[242px] left-[221px] top-[121px] w-[263px]" data-name="Hand and iPhone 16 Pro">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <img alt="" className="absolute h-[117.55%] left-[-44.37%] max-w-none top-[-17.55%] w-[144.37%]" src={imgHandAndIPhone16Pro} />
        </div>
      </div>
      <div className="absolute h-[352px] left-[40px] top-[-3px] w-[205px]" data-name="iPhone 16 Pro">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <img alt="" className="absolute h-[131.43%] left-[-156.95%] max-w-none top-[-25.55%] w-[316.46%]" src={imgIPhone16Pro} />
        </div>
      </div>
    </div>
  );
}

function Frame21() {
  return (
    <div className="bg-black content-stretch flex h-[353px] items-center justify-center relative rounded-[25px] shrink-0 w-[442px]">
      <div className="h-[243px] relative shrink-0 w-[414px]" data-name="image 1">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage1} />
      </div>
    </div>
  );
}

function Frame22() {
  return (
    <div className="h-[353px] relative rounded-[25px] shrink-0 w-[442px]">
      <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none rounded-[25px] size-full" src={imgFrame19} />
    </div>
  );
}

function Frame23() {
  return (
    <div className="h-[353px] relative rounded-[25px] shrink-0 w-[442px]">
      <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none rounded-[25px] size-full" src={imgFrame20} />
    </div>
  );
}

function Frame19() {
  return (
    <div className="content-stretch flex gap-[10px] h-[352px] items-center relative shrink-0 w-[1512px]">
      <Frame20 />
      <Frame21 />
      <Frame22 />
      <Frame23 />
    </div>
  );
}

function Frame9() {
  return (
    <div className="content-stretch flex flex-col gap-[15px] h-[800px] items-center justify-center relative rounded-[45px] shrink-0 w-[1408px]">
      <Frame14 />
      <Frame19 />
    </div>
  );
}

function Frame1() {
  return (
    <div className="content-stretch flex h-[848px] items-center justify-center relative rounded-[45px] shrink-0 w-[1454px]">
      <Frame9 />
    </div>
  );
}

function MacBookPro() {
  return (
    <div className="bg-[#fdfff2] h-[982px] relative shrink-0 w-full" data-name="MacBook Pro 14' - 1">
      <div className="flex flex-col items-center justify-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex flex-col gap-[10px] items-center justify-center p-[10px] relative size-full">
          <Frame />
          <Frame1 />
        </div>
      </div>
    </div>
  );
}

function Frame25() {
  return (
    <div className="relative rounded-[105px] shrink-0 size-[615px]">
      <div className="absolute inset-0 overflow-hidden pointer-events-none rounded-[105px]">
        <img alt="" className="absolute h-[133.22%] left-0 max-w-none top-[-16.61%] w-full" src={imgFrame12} />
      </div>
    </div>
  );
}

function Frame31() {
  return (
    <div className="content-stretch flex flex-col h-[631px] items-start justify-center relative shrink-0 w-[640px]">
      <Frame25 />
    </div>
  );
}

function Frame37() {
  return (
    <div className="bg-[#1affbe] content-stretch flex h-[49px] items-center justify-center relative rounded-[25px] shrink-0 w-[172px]">
      <p className="font-['Aeonik_TRIAL:Regular','Noto_Sans:Regular',sans-serif] leading-[normal] relative shrink-0 text-[20px] text-black text-center whitespace-nowrap" style={{ fontVariationSettings: "'CTGR' 0, 'wdth' 100, 'wght' 400" }}>
        Acerca de Mí
      </p>
    </div>
  );
}

function Frame35() {
  return (
    <div className="content-stretch flex h-[48px] items-center relative shrink-0 w-[570px]">
      <Frame37 />
    </div>
  );
}

function Frame36() {
  return (
    <div className="content-stretch flex items-center relative shrink-0 w-[570px]">
      <p className="font-['Aeonik_TRIAL:Bold',sans-serif] leading-[0] not-italic relative shrink-0 text-[42px] text-black w-[404px]">
        <span className="leading-[normal]">{`Transformo ideas en productos funcionales, intuitivos y centrados en las `}</span>
        <span className="leading-[normal] text-[#0004ff]">personas</span>
      </p>
    </div>
  );
}

function Frame32() {
  return (
    <div className="content-stretch flex flex-col gap-[15px] h-[631px] items-center justify-center relative shrink-0 w-[640px]">
      <Frame35 />
      <Frame36 />
      <p className="font-['Aeonik_TRIAL:Regular','Noto_Sans:Regular',sans-serif] leading-[36px] relative shrink-0 text-[22px] text-black w-[570px]" style={{ fontVariationSettings: "'CTGR' 0, 'wdth' 100, 'wght' 400" }}>
        Soy un diseñador apasionado por crear experiencias digitales que no solo se vean bien, sino que realmente funcionen. Me enfoco en entender las necesidades de los usuarios para diseñar soluciones claras, accesibles y eficientes.
      </p>
    </div>
  );
}

function Frame24() {
  return (
    <div className="content-stretch flex gap-[10px] h-[635px] items-center justify-center relative shrink-0 w-[1350px]">
      <Frame31 />
      <Frame32 />
    </div>
  );
}

function MacBookPro3() {
  return (
    <div id="about" className="bg-[#fdfff2] content-stretch flex flex-col h-[745px] items-center justify-center overflow-clip p-[10px] relative shrink-0 w-[1512px]" data-name="MacBook Pro 14' - 5">
      <Frame24 />
    </div>
  );
}

function Frame39() {
  return (
    <div className="bg-[#1affbe] content-stretch flex h-[49px] items-center justify-center relative rounded-[25px] shrink-0 w-[208px]">
      <p className="font-['Aeonik_TRIAL:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[20px] text-black text-center whitespace-nowrap">Ultimos Proyectos</p>
    </div>
  );
}

function Frame38() {
  return (
    <div className="content-stretch flex h-[48px] items-center relative shrink-0 w-[570px]">
      <Frame39 />
    </div>
  );
}

function Frame33() {
  return (
    <div className="content-stretch flex flex-col gap-[5px] items-start justify-center relative shrink-0">
      <Frame38 />
      <p className="font-['Aeonik_TRIAL:Bold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[68px] text-black text-center whitespace-nowrap">Explora mis proyectos</p>
    </div>
  );
}

function Frame26() {
  return (
    <div className="content-stretch flex flex-col items-start justify-center relative shrink-0 w-[1350px]">
      <Frame33 />
    </div>
  );
}

function Frame40() {
  return (
    <div className="content-stretch flex items-start relative shrink-0 w-[615px]">
      <p className="font-['Aeonik_TRIAL:Bold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[42px] text-black text-center whitespace-nowrap">Turquesa Travel</p>
    </div>
  );
}

function Frame29() {
  return (
    <div className="content-stretch flex items-center justify-center relative shrink-0 w-[617px]">
      <p className="font-['Aeonik_TRIAL:Regular','Noto_Sans:Regular',sans-serif] leading-[36px] relative shrink-0 text-[22px] text-black w-[614px]" style={{ fontVariationSettings: "'CTGR' 0, 'wdth' 100, 'wght' 400" }}>
        Agencia formal de viajes y Tours que combinan tradición, cultura y naturaleza de Ayacucho con gran cantidad de paquetes y combos y reconocimiento a nivel nacional por su confanza y calidad al momento de hacer un Viaje.
      </p>
    </div>
  );
}

function ArrowBack() {
  return (
    <div className="relative size-[31.322px]" data-name="arrow-back">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 31.3216 31.3216">
        <g id="arrow-back">
          <path d={svgPaths.p1da4e840} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
        </g>
      </svg>
    </div>
  );
}

function Frame30() {
  return (
    <div className="content-stretch flex items-center justify-center relative shrink-0 size-[30px]">
      <div className="flex items-center justify-center relative shrink-0 size-[44.197px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "21" } as React.CSSProperties}>
        <div className="flex-none rotate-[138.82deg]">
          <ArrowBack />
        </div>
      </div>
    </div>
  );
}

function Frame42() {
  const handleViewProject = () => {
    window.open('https://turquesa-travel.com', '_blank');
  };

  return (
    <button onClick={handleViewProject} className="bg-black content-stretch flex gap-[5px] h-[53px] items-center justify-center relative rounded-[35px] shrink-0 w-[227px] cursor-pointer hover:opacity-80 transition-opacity">
      <p className="font-['Aeonik_TRIAL:Bold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[22px] text-center text-white whitespace-nowrap">Ver Proyecto</p>
      <Frame30 />
    </button>
  );
}

function Frame41() {
  return (
    <div className="content-stretch flex items-start relative shrink-0 w-[615px]">
      <Frame42 />
    </div>
  );
}

function Frame28() {
  return (
    <div className="content-stretch flex flex-col gap-[10px] h-[463px] items-center justify-center relative shrink-0 w-[750px]">
      <Frame40 />
      <Frame29 />
      <Frame41 />
    </div>
  );
}

function Frame43() {
  return (
    <div className="bg-black content-stretch flex h-[415px] items-center justify-center overflow-clip relative rounded-[55px] shrink-0 w-[535px]">
      <div className="h-[295px] relative shrink-0 w-[499px]" data-name="image 2">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage2} />
      </div>
    </div>
  );
}

function Frame27() {
  return (
    <div className="content-stretch flex gap-[15px] items-center justify-center relative rounded-[45px] shrink-0 w-[1350px]">
      <Frame28 />
      <Frame43 />
    </div>
  );
}

function Frame46() {
  return (
    <div className="content-stretch flex items-start relative shrink-0 w-[615px]">
      <p className="font-['Aeonik_TRIAL:Bold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[42px] text-black text-center whitespace-nowrap">M.R.I Bombas Industriales</p>
    </div>
  );
}

function Frame47() {
  return (
    <div className="content-stretch flex items-center justify-center relative shrink-0 w-[617px]">
      <p className="font-['Aeonik_TRIAL:Regular','Noto_Sans:Regular',sans-serif] leading-[36px] relative shrink-0 text-[22px] text-black w-[614px]" style={{ fontVariationSettings: "'CTGR' 0, 'wdth' 100, 'wght' 400" }}>
        Pagina web diseñada para mostrar información de los productos industriales que vende y distribuye la empresa asi como un catálogo integrado y servicios que ofrece la compañía.
      </p>
    </div>
  );
}

function ArrowBack1() {
  return (
    <div className="relative size-[31.322px]" data-name="arrow-back">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 31.3216 31.3216">
        <g id="arrow-back">
          <path d={svgPaths.p1da4e840} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
        </g>
      </svg>
    </div>
  );
}

function Frame50() {
  return (
    <div className="content-stretch flex items-center justify-center relative shrink-0 size-[30px]">
      <div className="flex items-center justify-center relative shrink-0 size-[44.197px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "21" } as React.CSSProperties}>
        <div className="flex-none rotate-[138.82deg]">
          <ArrowBack1 />
        </div>
      </div>
    </div>
  );
}

function Frame49() {
  const handleViewProject = () => {
    window.open('https://mri-bombas.com', '_blank');
  };

  return (
    <button onClick={handleViewProject} className="bg-black content-stretch flex gap-[5px] h-[53px] items-center justify-center relative rounded-[35px] shrink-0 w-[227px] cursor-pointer hover:opacity-80 transition-opacity">
      <p className="font-['Aeonik_TRIAL:Bold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[22px] text-center text-white whitespace-nowrap">Ver Proyecto</p>
      <Frame50 />
    </button>
  );
}

function Frame48() {
  return (
    <div className="content-stretch flex items-start relative shrink-0 w-[615px]">
      <Frame49 />
    </div>
  );
}

function Frame45() {
  return (
    <div className="content-stretch flex flex-col gap-[10px] h-[463px] items-center justify-center relative shrink-0 w-[750px]">
      <Frame46 />
      <Frame47 />
      <Frame48 />
    </div>
  );
}

function Frame51() {
  return (
    <div className="bg-gradient-to-b content-stretch flex from-[#335cff] h-[415px] items-center justify-center overflow-clip relative rounded-[55px] shrink-0 to-[#76b6ff] w-[535px]">
      <div className="absolute h-[314px] left-[7px] top-[51px] w-[499px]" data-name="​ HP Elite Dragonfly">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <img alt="" className="absolute h-[132.43%] left-[-1.86%] max-w-none top-[-16.21%] w-[110.77%]" src={imgHpEliteDragonfly} />
        </div>
      </div>
    </div>
  );
}

function Frame44() {
  return (
    <div className="content-stretch flex gap-[15px] items-center justify-center relative rounded-[45px] shrink-0 w-[1350px]">
      <Frame45 />
      <Frame51 />
    </div>
  );
}

function Frame54() {
  return (
    <div className="content-stretch flex items-start relative shrink-0 w-[615px]">
      <p className="font-['Aeonik_TRIAL:Bold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[42px] text-black text-center whitespace-nowrap">Twenty One Pilots - Teleticket</p>
    </div>
  );
}

function Frame55() {
  return (
    <div className="content-stretch flex items-center justify-center relative shrink-0 w-[617px]">
      <p className="font-['Aeonik_TRIAL:Regular','Noto_Sans:Regular',sans-serif] leading-[36px] relative shrink-0 text-[22px] text-black w-[614px]" style={{ fontVariationSettings: "'CTGR' 0, 'wdth' 100, 'wght' 400" }}>
        Diseñé la Web de Twenty One Pilots orientada a ventas luego de enterarme de que estuvieron a punto de cerrar negociaciones para dar un concierto en Perú, el cual nunca llegó pero lo vi como una oportunidad de diseñar algo que me hubiera gustado ver al momento de comprar mi entrada
      </p>
    </div>
  );
}

function Frame53() {
  return (
    <div className="content-stretch flex flex-col gap-[10px] h-[463px] items-center justify-center relative shrink-0 w-[750px]">
      <Frame54 />
      <Frame55 />
    </div>
  );
}

function Frame56() {
  return (
    <div className="bg-gradient-to-b content-stretch flex from-[yellow] h-[415px] items-center justify-center overflow-clip relative rounded-[55px] shrink-0 to-[#ff2600] w-[535px]">
      <div className="absolute flex h-[594.48px] items-center justify-center left-[-34px] top-[-89.67px] w-[577.001px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "21" } as React.CSSProperties}>
        <div className="flex-none rotate-[-26.95deg]">
          <div className="h-[455.558px] relative w-[415.662px]" data-name="MacBook Air (15 inch)">
            <div className="absolute inset-0 overflow-hidden pointer-events-none">
              <img alt="" className="absolute h-[107.58%] left-[-25.54%] max-w-none top-[-3.94%] w-[154.68%]" src={imgMacBookAir15Inch} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function Frame52() {
  return (
    <div className="content-stretch flex gap-[15px] items-center justify-center relative rounded-[45px] shrink-0 w-[1350px]">
      <Frame53 />
      <Frame56 />
    </div>
  );
}

function Frame59() {
  return (
    <div className="content-stretch flex items-start relative shrink-0 w-[615px]">
      <p className="font-['Aeonik_TRIAL:Bold','Noto_Sans:Bold',sans-serif] leading-[normal] relative shrink-0 text-[42px] text-black text-center whitespace-nowrap" style={{ fontVariationSettings: "'CTGR' 0, 'wdth' 100, 'wght' 700" }}>
        Glúcida
      </p>
    </div>
  );
}

function Frame60() {
  return (
    <div className="content-stretch flex items-center justify-center relative shrink-0 w-[617px]">
      <p className="font-['Aeonik_TRIAL:Regular','Noto_Sans:Regular',sans-serif] leading-[36px] relative shrink-0 text-[22px] text-black w-[614px]" style={{ fontVariationSettings: "'CTGR' 0, 'wdth' 100, 'wght' 400" }}>
        Propuesta de aplicación móvil diseñada orientada al tracking y seguimiento continuo diario de los niveles de glucosa y de azucar para registrar niveles y poder visualizar el progreso y proceso mediante indicadores y gráficos claros
      </p>
    </div>
  );
}

function Frame58() {
  return (
    <div className="content-stretch flex flex-col gap-[10px] h-[463px] items-center justify-center relative shrink-0 w-[750px]">
      <Frame59 />
      <Frame60 />
    </div>
  );
}

function Frame61() {
  return (
    <div className="bg-gradient-to-b content-stretch flex from-[#00af5d] gap-[10px] h-[415px] items-center justify-center overflow-clip relative rounded-[55px] shrink-0 to-[#0c3bb1] w-[535px]">
      <div className="absolute h-[387px] left-[31.5px] top-0 w-[252px]" data-name="iPhone 13">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <img alt="" className="absolute h-[105.79%] left-[-73.13%] max-w-none top-[-2.89%] w-[236.12%]" src={imgIPhone13} />
        </div>
      </div>
      <div className="absolute h-[308px] left-[290.5px] top-[115px] w-[334px]" data-name="Hand and iPhone 16 Pro">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <img alt="" className="absolute h-[117.55%] left-[-44.37%] max-w-none top-[-17.55%] w-[144.37%]" src={imgHandAndIPhone16Pro} />
        </div>
      </div>
    </div>
  );
}

function Frame57() {
  return (
    <div className="content-stretch flex gap-[15px] items-center justify-center relative rounded-[45px] shrink-0 w-[1350px]">
      <Frame58 />
      <Frame61 />
    </div>
  );
}

function Frame64() {
  return (
    <div className="content-stretch flex items-start relative shrink-0 w-[615px]">
      <p className="font-['Aeonik_TRIAL:Bold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[42px] text-black text-center whitespace-nowrap">PetCare</p>
    </div>
  );
}

function Frame65() {
  return (
    <div className="content-stretch flex items-center justify-center relative shrink-0 w-[617px]">
      <p className="font-['Aeonik_TRIAL:Regular','Noto_Sans:Regular',sans-serif] leading-[36px] relative shrink-0 text-[22px] text-black w-[614px]" style={{ fontVariationSettings: "'CTGR' 0, 'wdth' 100, 'wght' 400" }}>
        Aplicación móvil enfocada en mejorar la gestión y el cuidado de mascotas, integrando funcionalidades como registro de mascotas, reservas de citas veterinarias y acceso a servicios especializados. Además de contar con un modulo de adopción
      </p>
    </div>
  );
}

function Frame63() {
  return (
    <div className="content-stretch flex flex-col gap-[10px] h-[463px] items-center justify-center relative shrink-0 w-[750px]">
      <Frame64 />
      <Frame65 />
    </div>
  );
}

function Frame66() {
  return (
    <div className="h-[415px] relative rounded-[55px] shrink-0 w-[535px]">
      <div className="absolute inset-0 overflow-hidden pointer-events-none rounded-[55px]">
        <img alt="" className="absolute h-[119.45%] left-[-19.47%] max-w-none top-[0.16%] w-[138.97%]" src={imgFrame25} />
      </div>
    </div>
  );
}

function Frame62() {
  return (
    <div className="content-stretch flex gap-[15px] items-center justify-center relative rounded-[80px] shrink-0 w-[1350px]">
      <Frame63 />
      <Frame66 />
    </div>
  );
}

function Frame69() {
  return (
    <div className="content-stretch flex items-start relative shrink-0 w-[615px]">
      <p className="font-['Aeonik_TRIAL:Bold','Noto_Sans:Bold',sans-serif] leading-[normal] relative shrink-0 text-[42px] text-black text-center whitespace-nowrap" style={{ fontVariationSettings: "'CTGR' 0, 'wdth' 100, 'wght' 700" }}>
        Taipá!
      </p>
    </div>
  );
}

function Frame70() {
  return (
    <div className="content-stretch flex items-center justify-center relative shrink-0 w-[617px]">
      <p className="font-['Aeonik_TRIAL:Regular','Noto_Sans:Regular',sans-serif] leading-[36px] relative shrink-0 text-[22px] text-black w-[614px]" style={{ fontVariationSettings: "'CTGR' 0, 'wdth' 100, 'wght' 400" }}>
        Propuesta de aplicación móvil diseñada orientada al tracking y seguimiento continuo diario de los niveles de glucosa y de azucar para registrar niveles y poder visualizar el progreso y proceso mediante indicadores y gráficos claros
      </p>
    </div>
  );
}

function Frame68() {
  return (
    <div className="content-stretch flex flex-col gap-[10px] h-[463px] items-center justify-center relative shrink-0 w-[750px]">
      <Frame69 />
      <Frame70 />
    </div>
  );
}

function Frame71() {
  return (
    <div className="content-stretch flex gap-[10px] h-[415px] items-center justify-center overflow-clip relative rounded-[55px] shrink-0 w-[535px]">
      <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none rounded-[55px] size-full" src={imgFrame26} />
      <div className="absolute h-[445px] left-[127px] top-[-6px] w-[378px]" data-name="iPhone 13">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <img alt="" className="absolute h-full left-[-41.46%] max-w-none top-0 w-[157.24%]" src={imgIPhone14} />
        </div>
      </div>
      <div className="h-[463px] relative shrink-0 w-[617px]" data-name="Hand and iPhone 16 Pro">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgHandAndIPhone16Pro1} />
      </div>
    </div>
  );
}

function Frame67() {
  return (
    <div className="content-stretch flex gap-[15px] items-center justify-center relative rounded-[45px] shrink-0 w-[1350px]">
      <Frame68 />
      <Frame71 />
    </div>
  );
}

function Frame34() {
  return (
    <div className="content-stretch flex flex-col gap-[10px] items-center relative shrink-0">
      <Frame27 />
      <Frame44 />
      <Frame52 />
      <Frame57 />
      <Frame62 />
      <Frame67 />
    </div>
  );
}

function MacBookPro1() {
  return (
    <div id="projects" className="bg-[#fdfff2] h-[3168px] relative shrink-0 w-full" data-name="MacBook Pro 14' - 3">
      <div className="flex flex-col items-center justify-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex flex-col gap-[10px] items-center justify-center p-[10px] relative size-full">
          <Frame26 />
          <Frame34 />
        </div>
      </div>
    </div>
  );
}

function Frame75() {
  return (
    <div className="bg-[#1affbe] content-stretch flex h-[49px] items-center justify-center relative rounded-[25px] shrink-0 w-[208px]">
      <p className="font-['Aeonik_TRIAL:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[20px] text-black text-center whitespace-nowrap">Mi Aprendizaje</p>
    </div>
  );
}

function Frame74() {
  return (
    <div className="content-stretch flex h-[48px] items-center relative shrink-0 w-[570px]">
      <Frame75 />
    </div>
  );
}

function Frame73() {
  return (
    <div className="content-stretch flex flex-col gap-[5px] items-start justify-center relative shrink-0">
      <Frame74 />
      <p className="font-['Aeonik_TRIAL:Bold','Noto_Sans:Bold',sans-serif] leading-[normal] relative shrink-0 text-[68px] text-black text-center whitespace-nowrap" style={{ fontVariationSettings: "'CTGR' 0, 'wdth' 100, 'wght' 700" }}>{`Experiencia y Educación `}</p>
    </div>
  );
}

function Frame72() {
  return (
    <div className="content-stretch flex flex-col items-start justify-center relative shrink-0 w-[1350px]">
      <Frame73 />
    </div>
  );
}

function Frame79() {
  return (
    <div className="content-stretch flex flex-col gap-[5px] items-start leading-[normal] relative shrink-0 text-[22px] text-black whitespace-nowrap">
      <p className="font-['Aeonik_TRIAL:Bold',sans-serif] not-italic relative shrink-0">A.M. Code</p>
      <p className="font-['Aeonik_TRIAL:Regular','Noto_Sans:Regular',sans-serif] relative shrink-0" style={{ fontVariationSettings: "'CTGR' 0, 'wdth' 100, 'wght' 400" }}>
        Diseñador UX/UI
      </p>
    </div>
  );
}

function Frame80() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0">
      <p className="font-['Aeonik_TRIAL:Bold','Noto_Sans:Bold',sans-serif] leading-[normal] relative shrink-0 text-[22px] text-black whitespace-nowrap" style={{ fontVariationSettings: "'CTGR' 0, 'wdth' 100, 'wght' 700" }}>
        2025/09 - 2026/02
      </p>
    </div>
  );
}

function Frame78() {
  return (
    <div className="content-stretch flex h-[61px] items-center justify-between relative shrink-0 w-[563px]">
      <Frame79 />
      <Frame80 />
    </div>
  );
}

function Frame81() {
  return (
    <div className="content-stretch flex items-center justify-between relative shrink-0 w-[563px]">
      <p className="flex-[1_0_0] font-['Aeonik_TRIAL:Regular',sans-serif] leading-[26px] min-h-px min-w-px not-italic relative text-[18px] text-black">Entre mis funciones principales durante este tiempo de trabajo fueron armar prototipos Web y Mobile para posteriormente mandarlas a desarrollo una vez se aprueben propuestas de desarrollo y de mejora para plataformas existentes.</p>
    </div>
  );
}

function CloudDownloadOutline() {
  return (
    <div className="relative shrink-0 size-[25px]" data-name="cloud-download-outline">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 25 25">
        <g clipPath="url(#clip0_1_233)" id="cloud-download-outline">
          <path d={svgPaths.p5f53598} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
        </g>
        <defs>
          <clipPath id="clip0_1_233">
            <rect fill="white" height="25" width="25" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Frame84() {
  return (
    <div className="content-stretch flex h-[29px] items-center relative shrink-0">
      <p className="font-['Aeonik_TRIAL:Bold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[18px] text-white whitespace-nowrap">Descargar CV</p>
    </div>
  );
}

function Frame83() {
  const handleDownloadCV = () => {
    // Aquí debes poner la URL de tu CV
    window.open('/cv-diego-mendez.pdf', '_blank');
  };

  return (
    <button onClick={handleDownloadCV} className="bg-black content-stretch flex gap-[10px] h-[49px] items-center justify-center relative rounded-[35px] shrink-0 w-[232px] cursor-pointer hover:opacity-80 transition-opacity">
      <CloudDownloadOutline />
      <Frame84 />
    </button>
  );
}

function LogoLinkedin() {
  return (
    <div className="relative shrink-0 size-[25px]" data-name="logo-linkedin">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 25 25">
        <g id="logo-linkedin">
          <path d={svgPaths.p4de0bf0} fill="var(--fill-0, white)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Frame85() {
  const handleLinkedIn = () => {
    window.open('https://linkedin.com/in/tu-perfil', '_blank');
  };

  return (
    <button onClick={handleLinkedIn} className="bg-black content-stretch flex items-center justify-center relative rounded-[35px] shrink-0 size-[49px] cursor-pointer hover:opacity-80 transition-opacity">
      <LogoLinkedin />
    </button>
  );
}

function Frame82() {
  return (
    <div className="content-stretch flex gap-[10px] items-start relative shrink-0 w-[563px]">
      <Frame83 />
      <Frame85 />
    </div>
  );
}

function Frame77() {
  return (
    <div className="content-stretch flex flex-col gap-[10px] h-[558px] items-center py-[25px] relative shrink-0 w-[589px]">
      <Frame78 />
      <Frame81 />
      <p className="font-['Aeonik_TRIAL:Regular','Noto_Sans:Regular',sans-serif] leading-[26px] relative shrink-0 text-[18px] text-black w-[563px]" style={{ fontVariationSettings: "'CTGR' 0, 'wdth' 100, 'wght' 400" }}>{`Además de eso colaboré en el equipo de Diseño Gráfico con la creación de Social Media para las publicaciones y presentación de marca de la Empresa `}</p>
      <Frame82 />
    </div>
  );
}

function Frame88() {
  return (
    <div className="content-stretch flex flex-col gap-[5px] items-start leading-[normal] relative shrink-0 text-[22px] text-black whitespace-nowrap">
      <p className="font-['Aeonik_TRIAL:Bold',sans-serif] not-italic relative shrink-0">CODERHOUSE</p>
      <p className="font-['Aeonik_TRIAL:Regular','Noto_Sans:Regular',sans-serif] relative shrink-0" style={{ fontVariationSettings: "'CTGR' 0, 'wdth' 100, 'wght' 400" }}>
        Diseño UX/UI Avanzado
      </p>
    </div>
  );
}

function Frame89() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0">
      <p className="font-['Aeonik_TRIAL:Bold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[22px] text-black whitespace-nowrap">CURSANDO</p>
    </div>
  );
}

function Frame87() {
  return (
    <div className="content-stretch flex h-[61px] items-center justify-between relative shrink-0 w-[702px]">
      <Frame88 />
      <Frame89 />
    </div>
  );
}

function Frame91() {
  return (
    <div className="content-stretch flex flex-col gap-[5px] items-start leading-[normal] not-italic relative shrink-0 text-[22px] text-black whitespace-nowrap">
      <p className="font-['Aeonik_TRIAL:Bold',sans-serif] relative shrink-0">IBM SkillsBuild</p>
      <p className="font-['Aeonik_TRIAL:Regular',sans-serif] relative shrink-0">User Experience Design Fundamentals</p>
    </div>
  );
}

function Frame92() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0">
      <p className="font-['Aeonik_TRIAL:Bold','Noto_Sans:Bold',sans-serif] leading-[normal] relative shrink-0 text-[22px] text-black whitespace-nowrap" style={{ fontVariationSettings: "'CTGR' 0, 'wdth' 100, 'wght' 700" }}>
        02/2025
      </p>
    </div>
  );
}

function Frame90() {
  return (
    <div className="content-stretch flex h-[61px] items-center justify-between relative shrink-0 w-[702px]">
      <Frame91 />
      <Frame92 />
    </div>
  );
}

function Frame94() {
  return (
    <div className="content-stretch flex flex-col gap-[5px] items-start leading-[normal] not-italic relative shrink-0 text-[22px] text-black whitespace-nowrap">
      <p className="font-['Aeonik_TRIAL:Bold',sans-serif] relative shrink-0">XBOX</p>
      <p className="font-['Aeonik_TRIAL:Regular',sans-serif] relative shrink-0">Fundamentals of Graphic Design</p>
    </div>
  );
}

function Frame95() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0">
      <p className="font-['Aeonik_TRIAL:Bold','Noto_Sans:Bold',sans-serif] leading-[normal] relative shrink-0 text-[22px] text-black whitespace-nowrap" style={{ fontVariationSettings: "'CTGR' 0, 'wdth' 100, 'wght' 700" }}>
        02/2025
      </p>
    </div>
  );
}

function Frame93() {
  return (
    <div className="content-stretch flex h-[61px] items-center justify-between relative shrink-0 w-[702px]">
      <Frame94 />
      <Frame95 />
    </div>
  );
}

function Frame97() {
  return (
    <div className="content-stretch flex flex-col gap-[5px] items-start leading-[normal] relative shrink-0 text-[22px] text-black whitespace-nowrap">
      <p className="font-['Aeonik_TRIAL:Bold',sans-serif] not-italic relative shrink-0">Google</p>
      <p className="font-['Aeonik_TRIAL:Regular','Noto_Sans:Regular',sans-serif] relative shrink-0" style={{ fontVariationSettings: "'CTGR' 0, 'wdth' 100, 'wght' 400" }}>
        Tools of the Trade: Linux and SQL
      </p>
    </div>
  );
}

function Frame98() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0">
      <p className="font-['Aeonik_TRIAL:Bold','Noto_Sans:Bold',sans-serif] leading-[normal] relative shrink-0 text-[22px] text-black whitespace-nowrap" style={{ fontVariationSettings: "'CTGR' 0, 'wdth' 100, 'wght' 700" }}>
        01/2025
      </p>
    </div>
  );
}

function Frame96() {
  return (
    <div className="content-stretch flex h-[61px] items-center justify-between relative shrink-0 w-[702px]">
      <Frame97 />
      <Frame98 />
    </div>
  );
}

function Frame100() {
  return (
    <div className="content-stretch flex flex-col gap-[5px] h-[80px] items-start relative shrink-0 text-[22px] text-black">
      <p className="font-['Aeonik_TRIAL:Bold',sans-serif] leading-[normal] not-italic relative shrink-0 whitespace-nowrap">Google</p>
      <div className="font-['Aeonik_TRIAL:Regular','Noto_Sans:Regular',sans-serif] h-[23px] leading-[0] relative shrink-0 w-[463px]" style={{ fontVariationSettings: "'CTGR' 0, 'wdth' 100, 'wght' 400" }}>
        <p className="leading-[normal] mb-0">Seguridad informática: defensa contra las artes oscuras digitales</p>
        <p className="leading-[normal]">&nbsp;</p>
      </div>
    </div>
  );
}

function Frame101() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0">
      <p className="font-['Aeonik_TRIAL:Bold','Noto_Sans:Bold',sans-serif] leading-[normal] relative shrink-0 text-[22px] text-black whitespace-nowrap" style={{ fontVariationSettings: "'CTGR' 0, 'wdth' 100, 'wght' 700" }}>
        01/2025
      </p>
    </div>
  );
}

function Frame99() {
  return (
    <div className="content-stretch flex items-center justify-between relative shrink-0 w-[702px]">
      <Frame100 />
      <Frame101 />
    </div>
  );
}

function Frame103() {
  return (
    <div className="content-stretch flex flex-col gap-[5px] items-start leading-[normal] relative shrink-0 text-[22px] text-black whitespace-nowrap">
      <p className="font-['Aeonik_TRIAL:Bold',sans-serif] not-italic relative shrink-0">IBM</p>
      <p className="font-['Aeonik_TRIAL:Regular','Noto_Sans:Regular',sans-serif] relative shrink-0" style={{ fontVariationSettings: "'CTGR' 0, 'wdth' 100, 'wght' 400" }}>
        Introduction to UX/UI Design
      </p>
    </div>
  );
}

function Frame104() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0">
      <p className="font-['Aeonik_TRIAL:Bold','Noto_Sans:Bold',sans-serif] leading-[normal] relative shrink-0 text-[22px] text-black whitespace-nowrap" style={{ fontVariationSettings: "'CTGR' 0, 'wdth' 100, 'wght' 700" }}>
        01/2025
      </p>
    </div>
  );
}

function Frame102() {
  return (
    <div className="content-stretch flex h-[61px] items-center justify-between relative shrink-0 w-[702px]">
      <Frame103 />
      <Frame104 />
    </div>
  );
}

function Frame106() {
  return (
    <div className="content-stretch flex flex-col gap-[5px] items-start leading-[normal] relative shrink-0 text-[22px] text-black whitespace-nowrap">
      <p className="font-['Aeonik_TRIAL:Bold','Noto_Sans:Bold',sans-serif] relative shrink-0" style={{ fontVariationSettings: "'CTGR' 0, 'wdth' 100, 'wght' 700" }}>
        Universidad Nacional de Ingeniería
      </p>
      <p className="font-['Aeonik_TRIAL:Regular','Noto_Sans:Regular',sans-serif] relative shrink-0" style={{ fontVariationSettings: "'CTGR' 0, 'wdth' 100, 'wght' 400" }}>
        Fundamentos de Figma para UX/UI
      </p>
    </div>
  );
}

function Frame107() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0">
      <p className="font-['Aeonik_TRIAL:Bold','Noto_Sans:Bold',sans-serif] leading-[normal] relative shrink-0 text-[22px] text-black whitespace-nowrap" style={{ fontVariationSettings: "'CTGR' 0, 'wdth' 100, 'wght' 700" }}>
        01/2025
      </p>
    </div>
  );
}

function Frame105() {
  return (
    <div className="content-stretch flex h-[61px] items-center justify-between relative shrink-0 w-[702px]">
      <Frame106 />
      <Frame107 />
    </div>
  );
}

function Frame86() {
  return (
    <div className="content-stretch flex flex-col gap-[10px] h-[558px] items-center py-[10px] relative shrink-0 w-[754px]">
      <Frame87 />
      <Frame90 />
      <Frame93 />
      <Frame96 />
      <Frame99 />
      <Frame102 />
      <Frame105 />
    </div>
  );
}

function Frame76() {
  return (
    <div className="content-stretch flex gap-[5px] h-[583px] items-center justify-center relative shrink-0 w-[1350px]">
      <Frame77 />
      <Frame86 />
    </div>
  );
}

function MacBookPro2() {
  return (
    <div id="experience" className="bg-[#fdfff2] h-[829px] relative shrink-0 w-full" data-name="MacBook Pro 14' - 4">
      <div className="flex flex-col items-center justify-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex flex-col gap-[10px] items-center justify-center p-[10px] relative size-full">
          <Frame72 />
          <Frame76 />
        </div>
      </div>
    </div>
  );
}

function Frame109() {
  return (
    <div className="content-stretch flex flex-col gap-[15px] h-[304px] items-start justify-center leading-[normal] relative shrink-0 text-white w-[302px]">
      <p className="font-['Aeonik_TRIAL:Bold','Noto_Sans:Bold',sans-serif] relative shrink-0 text-[32px] text-center whitespace-nowrap" style={{ fontVariationSettings: "'CTGR' 0, 'wdth' 100, 'wght' 700" }}>
        Diego Méndez
      </p>
      <p className="font-['Aeonik_TRIAL:Regular','Noto_Sans:Regular',sans-serif] min-w-full relative shrink-0 text-[24px] w-[min-content]" style={{ fontVariationSettings: "'CTGR' 0, 'wdth' 100, 'wght' 400" }}>
        Diseñando para todos y para mí
      </p>
    </div>
  );
}

function LogoLinkedin1() {
  return (
    <div className="relative shrink-0 size-[25px]" data-name="logo-linkedin">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 25 25">
        <g id="logo-linkedin">
          <path d={svgPaths.p4de0bf0} fill="var(--fill-0, white)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Frame111() {
  const handleLinkedIn = () => {
    window.open('https://linkedin.com/in/tu-perfil', '_blank');
  };

  return (
    <button onClick={handleLinkedIn} className="content-stretch flex gap-[10px] h-[48px] items-center relative shrink-0 w-full cursor-pointer hover:opacity-70 transition-opacity">
      <LogoLinkedin1 />
      <p className="font-['Aeonik_TRIAL:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[24px] text-white whitespace-nowrap">LinkedIn</p>
    </button>
  );
}

function LogoWhatsapp() {
  return (
    <div className="relative shrink-0 size-[25px]" data-name="logo-whatsapp">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 25 25">
        <g id="logo-whatsapp">
          <path clipRule="evenodd" d={svgPaths.p5bb6800} fill="var(--fill-0, white)" fillRule="evenodd" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Frame112() {
  const handleWhatsApp = () => {
    window.open('https://wa.me/51973853069?text=Hola%20Diego,%20me%20gustaría%20contactarte', '_blank');
  };

  return (
    <button onClick={handleWhatsApp} className="content-stretch flex gap-[10px] h-[48px] items-center relative shrink-0 w-full cursor-pointer hover:opacity-70 transition-opacity">
      <LogoWhatsapp />
      <p className="font-['Aeonik_TRIAL:Regular','Noto_Sans:Regular',sans-serif] leading-[normal] relative shrink-0 text-[24px] text-white whitespace-nowrap" style={{ fontVariationSettings: "'CTGR' 0, 'wdth' 100, 'wght' 400" }}>
        +51 973853069
      </p>
    </button>
  );
}

function Frame110() {
  return (
    <div className="content-stretch flex flex-col gap-[15px] h-[304px] items-start justify-center relative shrink-0 w-[302px]">
      <p className="font-['Aeonik_TRIAL:Regular','Noto_Sans:Regular',sans-serif] leading-[normal] relative shrink-0 text-[24px] text-white w-full" style={{ fontVariationSettings: "'CTGR' 0, 'wdth' 100, 'wght' 400" }}>
        Contacto:
      </p>
      <Frame111 />
      <Frame112 />
    </div>
  );
}

function Frame108() {
  return (
    <div className="content-stretch flex h-[308px] items-center justify-between relative shrink-0 w-[1350px]">
      <Frame109 />
      <Frame110 />
    </div>
  );
}

function MacBookPro4() {
  const currentYear = new Date().getFullYear();

  return (
    <div id="footer" className="bg-[#0f0f11] relative shrink-0 w-full" data-name="MacBook Pro 14' - 6">
      <div className="flex flex-col items-center justify-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex flex-col items-center justify-center p-[10px] py-[40px] relative size-full gap-[30px]">
          <Frame108 />
          <div className="w-[1350px] h-[1px] bg-white/20" />
          <div className="content-stretch flex h-auto items-center justify-between relative shrink-0 w-[1350px] text-white/60">
            <p className="font-['Aeonik_TRIAL:Regular',sans-serif] text-[16px]">
              © {currentYear} Diego Méndez. Todos los derechos reservados.
            </p>
            <p className="font-['Aeonik_TRIAL:Regular',sans-serif] text-[16px]">
              Diseñado con ❤️ en Lima, Perú
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function Frame3() {
  return (
    <div className="content-stretch flex flex-col items-center justify-center relative size-full">
      <MacBookPro />
      <MacBookPro3 />
      <MacBookPro1 />
      <MacBookPro2 />
      <MacBookPro4 />
    </div>
  );
}